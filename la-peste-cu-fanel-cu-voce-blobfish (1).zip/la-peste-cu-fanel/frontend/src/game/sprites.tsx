import { Image } from "expo-image";
import { View, Text } from "react-native";

import { makeStyles, useTheme } from "@/src/theme";
import { BlobSprite, SharkSprite, SnailSprite, SquidSprite } from "@/src/game/creatures";

export const FISH_FACE = require("../../assets/images/fish-face.png");
export const PLAYER_FACE = require("../../assets/images/player-face.png");
export const BOMB_FACE = require("../../assets/images/bomb-face.png");
export const STAR_FACE = require("../../assets/images/star-face.png");

export type Kind = "fish" | "gold" | "green" | "bomb" | "star" | "time" | "double" | "squid" | "snail" | "blob" | "apricot" | "shark" | "boss" | "letter";

export function entityBox(kind: Kind, size: number) {
  switch (kind) {
    case "bomb": return { w: size * 1.1, h: size * 1.1 };
    case "star":
    case "time":
    case "double": return { w: size, h: size };
    case "squid": return { w: size * 0.8, h: size * 1.25 };
    case "snail": return { w: size * 1.3, h: size };
    case "blob": return { w: size * 1.15, h: size * 0.9 };
    case "apricot": return { w: size, h: size };
    case "letter": return { w: size * 1.2, h: size };
    case "shark": return { w: size * 2, h: size * 0.85 };
    default: return { w: size * 1.45, h: size };
  }
}

export function EntitySprite({ size, kind, dir, rot = 0 }: { size: number; kind: Kind; dir: 1 | -1; rot?: number }) {
  if (kind === "bomb") return <BombSprite size={size} />;
  if (kind === "star") return <StarfishSprite size={size} rot={rot} />;
  if (kind === "time" || kind === "double") return <PowerUpSprite size={size} kind={kind} />;
  if (kind === "squid") return <SquidSprite size={size} />;
  if (kind === "snail") return <SnailSprite size={size} dir={dir} />;
  if (kind === "blob") return <BlobSprite size={size} />;
  if (kind === "apricot") {
    return (
      <View style={{ width: size, height: size, alignItems: "center", justifyContent: "center" }}>
        <Text style={{ fontSize: size * 0.9, lineHeight: size }}>🍑</Text>
      </View>
    );
  }
  if (kind === "letter") {
    return (
      <View style={{ width: size * 1.2, height: size, alignItems: "center", justifyContent: "center" }}>
        <Text style={{ fontSize: size * 0.95, lineHeight: size * 1.05 }}>💌</Text>
      </View>
    );
  }
  if (kind === "shark") return <SharkSprite size={size} dir={dir} />;
  return <FishSprite size={size} kind={kind} dir={dir} />;
}

export function StarfishSprite({ size, rot = 0 }: { size: number; rot?: number }) {
  const { colors } = useTheme();
  const face = size * 0.5;
  return (
    <View style={{ width: size, height: size, alignItems: "center", justifyContent: "center" }}>
      <View style={{ position: "absolute", width: size, height: size, transform: [{ rotate: `${rot}deg` }] }}>
        {[0, 72, 144, 216, 288].map((a) => (
          <View key={a} style={{ position: "absolute", width: size, height: size, alignItems: "center", transform: [{ rotate: `${a}deg` }] }}>
            <View style={{ width: size * 0.24, height: size * 0.56, borderTopLeftRadius: size * 0.12, borderTopRightRadius: size * 0.12, borderBottomLeftRadius: size * 0.05, borderBottomRightRadius: size * 0.05, backgroundColor: colors.star }} />
          </View>
        ))}
      </View>
      <Image source={STAR_FACE} style={{ width: face, height: face, borderRadius: face / 2, borderWidth: 2, borderColor: colors.starDark, backgroundColor: colors.surfaceTertiary }} contentFit="cover" />
    </View>
  );
}

export function PowerUpSprite({ size, kind }: { size: number; kind: "time" | "double" }) {
  const { colors } = useTheme();
  return (
    <View style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: colors.powerBubble, borderWidth: 2, borderColor: colors.cloud, alignItems: "center", justifyContent: "center" }}>
      <Text style={{ color: kind === "time" ? colors.info : colors.brandPrimary, fontWeight: "900", fontSize: size * 0.32 }}>{kind === "time" ? "+5s" : "x2"}</Text>
    </View>
  );
}

export function FishSprite({ size, kind, dir }: { size: number; kind: Kind; dir: 1 | -1 }) {
  const { colors } = useTheme();
  if (kind === "bomb") return <BombSprite size={size} />;
  const body = kind === "gold" ? colors.gold : kind === "green" ? colors.green : kind === "boss" ? colors.boss : colors.fishBody;
  const fin = kind === "gold" ? colors.goldFin : kind === "green" ? colors.greenFin : kind === "boss" ? colors.bossFin : colors.fishFin;
  const face = size * 0.74;
  return (
    <View style={{ width: size * 1.45, height: size, transform: [{ scaleX: dir }] }}>
      <View style={{ position: "absolute", left: 0, top: size * 0.18, width: 0, height: 0, borderTopWidth: size * 0.32, borderBottomWidth: size * 0.32, borderLeftWidth: size * 0.42, borderTopColor: "transparent", borderBottomColor: "transparent", borderLeftColor: fin }} />
      <View style={{ position: "absolute", left: size * 0.28, top: size * 0.06, width: size * 1.15, height: size * 0.88, borderRadius: size, backgroundColor: body }} />
      <View style={{ position: "absolute", left: size * 0.5, top: -size * 0.04, width: size * 0.38, height: size * 0.22, borderTopLeftRadius: size, borderTopRightRadius: size * 0.1, backgroundColor: fin }} />
      <Image source={FISH_FACE} style={{ position: "absolute", right: size * 0.02, top: (size - face) / 2, width: face, height: face, borderRadius: face / 2, borderWidth: 2, borderColor: fin, backgroundColor: colors.surfaceTertiary, transform: [{ scaleX: dir }] }} contentFit="cover" />
    </View>
  );
}

export function BombSprite({ size }: { size: number }) {
  const { colors } = useTheme();
  return (
    <View style={{ width: size * 1.1, height: size * 1.1, alignItems: "center", justifyContent: "flex-end" }}>
      <View style={{ position: "absolute", top: 0, left: size * 0.55, width: 4, height: size * 0.3, backgroundColor: colors.rod, transform: [{ rotate: "25deg" }] }} />
      <View style={{ position: "absolute", top: -4, left: size * 0.62, width: 10, height: 10, borderRadius: 5, backgroundColor: colors.spark }} />
      <View style={{ width: size * 0.9, height: size * 0.9, borderRadius: size, backgroundColor: colors.bomb, alignItems: "center", justifyContent: "center" }}>
        <Image source={BOMB_FACE} style={{ width: size * 0.74, height: size * 0.74, borderRadius: size, backgroundColor: colors.bomb }} contentFit="cover" />
      </View>
    </View>
  );
}

const usePlayerStyles = makeStyles((c) => ({
  hull: { position: "absolute", width: 150, height: 34, backgroundColor: c.boat, borderBottomLeftRadius: 60, borderBottomRightRadius: 60, borderTopWidth: 6, borderTopColor: c.boatDark },
  body: { position: "absolute", width: 44, height: 52, backgroundColor: c.shirt, borderTopLeftRadius: 20, borderTopRightRadius: 20 },
  head: { position: "absolute", width: 54, height: 54, borderRadius: 27, borderWidth: 2, borderColor: c.shirt, backgroundColor: c.surfaceTertiary },
  arm: { position: "absolute", width: 8, height: 30, borderRadius: 4, backgroundColor: c.shirt },
  rod: { position: "absolute", width: 4, height: 76, borderRadius: 2, backgroundColor: c.rod },
  crack: { position: "absolute", width: 3, height: 16, borderRadius: 1.5, backgroundColor: c.crack },
}));

export function PlayerOnBoat({ x, waterY, damage = 0 }: { x: number; waterY: number; damage?: number }) {
  const s = usePlayerStyles();
  return (
    <>
      <View style={[s.body, { left: x - 22, top: waterY - 62 }]} />
      <View style={[s.arm, { left: x + 16, top: waterY - 62, transform: [{ rotate: "-50deg" }] }]} />
      <View style={[s.rod, { left: x + 39 - 2, top: waterY - 80 - 38, transform: [{ rotate: "35deg" }] }]} />
      <Image source={PLAYER_FACE} style={[s.head, { left: x - 27, top: waterY - 112 }]} contentFit="cover" />
      <View style={[s.hull, { left: x - 75, top: waterY - 22 }]} />
      {[-48, 30, -10, 52].slice(0, damage).map((dx, i) => <View key={i} style={[s.crack, { left: x + dx, top: waterY - 12 + (i % 2) * 6, transform: [{ rotate: i % 2 ? "-35deg" : "40deg" }] }]} />)}
    </>
  );
}
