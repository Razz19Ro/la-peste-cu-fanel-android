import { useCallback, useEffect, useRef, useState } from "react";
import { Platform, Pressable, Text, View, useWindowDimensions } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Image } from "expo-image";
import { useRouter } from "expo-router";
import * as Haptics from "expo-haptics";
import * as Sharing from "expo-sharing";
import { captureRef } from "react-native-view-shot";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { makeStyles, useTheme } from "@/src/theme";
import { storage } from "@/src/utils/storage";
import { submitScore } from "@/src/api";
import { initSounds, playBlobVoice, playSound } from "@/src/game/sounds";
import { EntitySprite, FishSprite, type Kind, PLAYER_FACE, PlayerOnBoat, entityBox } from "@/src/game/sprites";
import { GullSprite } from "@/src/game/creatures";

const GAME_TIME = 150; // 2 minute și 30 de secunde
const MAX_FISH = 7;
const DOUBLE_TIME = 10;
const BOAT_HP = 4;
const SHARK_EVERY = 10;
const BOSS_EVERY = 18;
const BOSS_TAPS = 8;
const FIGHT_WINDOW = 2.5;

const formatTime = (seconds: number) => {
  const total = Math.max(0, Math.ceil(seconds));
  return `${Math.floor(total / 60)}:${String(total % 60).padStart(2, "0")}`;
};

type Fish = {
  id: number;
  x: number;
  y: number;
  dir: 1 | -1;
  speed: number;
  kind: Kind;
  size: number;
  rot: number;
  baseY: number;
  phase: number;
};

const SIZES: Record<Kind, number> = {
  fish: 44, gold: 40, green: 38, bomb: 46, star: 50, time: 40, double: 40,
  squid: 44, snail: 42, blob: 44, apricot: 42, shark: 52, boss: 96, letter: 38,
};
const SPEEDS: Record<Kind, number> = {
  fish: 60, gold: 150, green: 210, bomb: 60, star: 30, time: 45, double: 45,
  squid: 70, snail: 18, blob: 40, apricot: 55, shark: 85, boss: 45, letter: 34,
};
const FISHY: Kind[] = ["fish", "gold", "green", "boss", "shark"];
const STEALABLE: Kind[] = ["fish", "gold", "green", "squid", "blob"];
const REGULAR = (k: Kind) => k !== "shark" && k !== "boss";

const pickKind = (hasSnail: boolean): Kind => {
  const r = Math.random();
  // The love letter is deliberately very rare: 0.4% of regular spawns.
  if (r < 0.004) return "letter";
  if (r < 0.134) return "bomb";
  if (r < 0.204) return "star";
  if (r < 0.254) return "green";
  if (r < 0.354) return "gold";
  if (r < 0.384) return "time";
  if (r < 0.414) return "double";
  if (r < 0.494) return "squid";
  if (r < 0.554) return "blob";
  if (r < 0.569) return hasSnail ? "apricot" : "snail";
  if (r < 0.619) return "apricot";
  return "fish";
};

const hitBox = (f: Fish) => {
  if (f.kind === "bomb") return { cx: f.x + f.size * 0.55, cy: f.y + f.size * 0.6, rx: f.size * 0.55, ry: f.size * 0.5 };
  if (f.kind === "fish" || f.kind === "gold" || f.kind === "green" || f.kind === "boss")
    return { cx: f.x + f.size * 0.72, cy: f.y + f.size / 2, rx: f.size * 0.62, ry: f.size * 0.5 };
  const { w, h } = entityBox(f.kind, f.size);
  return { cx: f.x + w / 2, cy: f.y + h / 2, rx: w / 2, ry: h / 2 };
};

// Seagull point theft odds: 1% 500, 5% 350, 10% 300, 25% 150, 30% 100, 31% 50
const stealAmount = () => {
  const r = Math.random() * 100;
  if (r < 1) return 500;
  if (r < 6) return 350;
  if (r < 16) return 300;
  if (r < 41) return 150;
  if (r < 71) return 100;
  return 50;
};

type Gull = {
  mode: "points" | "fish";
  phase: "in" | "out";
  x: number;
  y: number;
  dir: 1 | -1;
  flap: number;
  targetId: number | null;
  carry: Fish | null;
};
type Popup = { id: number; x: number; y: number; text: string; good: boolean; age: number };
type Boom = { x: number; y: number; age: number };
type GameState = {
  fish: Fish[];
  hook: { state: "idle" | "drop" | "reel" | "fight"; x: number; y: number; caught: Fish | null };
  fight: { taps: number; timer: number; startY: number };
  boatT: number;
  boatX: number;
  time: number;
  score: number;
  over: boolean;
  sunk: boolean;
  boatHp: number;
  nextShark: number;
  nextBoss: number;
  gull: Gull | null;
  pointGullTimes: number[];
  nextFishGull: number;
  popups: Popup[];
  boom: Boom | null;
  nextId: number;
  doubleLeft: number;
  elapsed: number;
};

const haptic = (type: "light" | "success" | "error") => {
  const p =
    type === "light"
      ? Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light)
      : Haptics.notificationAsync(type === "success" ? Haptics.NotificationFeedbackType.Success : Haptics.NotificationFeedbackType.Error);
  p?.catch?.(() => {});
};

export default function Game() {
  const s = useStyles();
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { width: W, height: H } = useWindowDimensions();

  const waterY = insets.top + 210;
  const rodTipY = waterY - 110;
  const idleY = waterY + 24;
  const bottomY = H - insets.bottom - 40;

  const dims = useRef({ W, H, waterY, idleY, bottomY });
  dims.current = { W, H, waterY, idleY, bottomY };

  const makeState = (): GameState => ({
    fish: [],
    hook: { state: "idle", x: W / 2, y: idleY, caught: null },
    fight: { taps: 0, timer: 0, startY: 0 },
    boatT: 0,
    boatX: W / 2,
    time: GAME_TIME,
    score: 0,
    over: false,
    sunk: false,
    boatHp: BOAT_HP,
    nextShark: SHARK_EVERY,
    nextBoss: BOSS_EVERY,
    gull: null,
    pointGullTimes: [12 + Math.random() * 13, 32 + Math.random() * 16],
    nextFishGull: 7 + Math.random() * 4,
    popups: [],
    boom: null,
    nextId: 1,
    doubleLeft: 0,
    elapsed: 0,
  });

  const g = useRef<GameState>(makeState());
  const [, setFrame] = useState(0);
  const [best, setBest] = useState(0);
  const [newBest, setNewBest] = useState(false);
  const [rank, setRank] = useState<number | null>(null);
  const [needsName, setNeedsName] = useState(false);
  const [shareMsg, setShareMsg] = useState("");
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const cardRef = useRef<any>(null);

  useEffect(() => {
    initSounds();
    storage.getItem("best_score", 0).then((v) => setBest(Number(v) || 0));
  }, []);

  const endGame = useCallback(async (score: number) => {
    const round = g.current;
    const prev = Number(await storage.getItem("best_score", 0)) || 0;
    if (g.current !== round) return;
    if (score > prev) {
      await storage.setItem("best_score", score);
      if (g.current !== round) return;
      setBest(score);
      setNewBest(true);
    } else {
      setBest(prev);
      setNewBest(false);
    }
    const name = String((await storage.getItem("player_name", "")) || "");
    if (g.current !== round) return;
    if (!name) {
      setNeedsName(true);
      return;
    }
    try {
      const r = await submitScore(name, score);
      if (g.current === round) setRank(r.rank);
    } catch {
      if (g.current === round) setShareMsg("Scorul nu a putut fi sincronizat cu clasamentul. Încearcă din nou mai târziu.");
    }
  }, []);

  const spawn = (st: GameState, forced?: Kind) => {
    const { W: w, waterY: wy, bottomY: by } = dims.current;
    const kind = forced ?? pickKind(st.fish.some((f) => f.kind === "snail"));
    const dir: 1 | -1 = Math.random() < 0.5 ? 1 : -1;
    const size = SIZES[kind] + (kind === "fish" ? Math.random() * 14 : 0);
    const { w: bw, h: bh } = entityBox(kind, size);
    const top = wy + 70;
    let y = top + Math.random() * Math.max(40, by - 50 - top);
    if (kind === "snail") y = by - 8 - bh / 2;
    if (kind === "shark") y = by - bh - 10;
    if (kind === "boss") y = top + 60 + Math.random() * Math.max(20, by - top - 220);
    const speed = SPEEDS[kind] + Math.random() * (kind === "star" || kind === "snail" ? 15 : kind === "shark" || kind === "boss" ? 20 : 70);
    st.fish.push({
      id: st.nextId++,
      x: dir === 1 ? -bw : w,
      y,
      baseY: y,
      phase: Math.random() * 6,
      rot: 0,
      dir,
      speed,
      kind,
      size,
    });
  };

  const pop = (st: GameState, x: number, y: number, text: string, good: boolean) =>
    st.popups.push({ id: st.nextId++, x, y, text, good, age: 0 });

  const finish = (st: GameState, sunk: boolean) => {
    st.over = true;
    st.sunk = sunk;
    haptic(sunk ? "error" : "success");
    endGame(st.score);
  };

  const scoreCatch = (st: GameState, c: Fish) => {
    const { waterY: wy, bottomY: by, idleY: iy } = dims.current;
    const depth = Math.min(1, Math.max(0, (c.y - wy) / (by - wy)));
    const base: Record<Kind, number> = {
      fish: 10 + Math.round(depth * 20),
      gold: 81,
      green: 100,
      squid: 50 + Math.floor(Math.random() * 51),
      snail: 500,
      blob: 1,
      apricot: -30,
      shark: 50,
      boss: 300,
      bomb: 0, star: 0, time: 0, double: 0, letter: 0,
    };
    const pts = base[c.kind] * (st.doubleLeft > 0 ? 2 : 1);
    if (c.kind === "apricot") {
      st.score = Math.max(0, st.score + pts);
      pop(st, st.hook.x, iy - 40, "-30", false);
      playSound("bad");
      haptic("error");
      return;
    }
    st.score += pts;
    pop(st, st.hook.x, iy - 40, `+${pts}`, true);
    if (c.kind === "blob") playBlobVoice();
    else playSound(c.kind === "snail" || c.kind === "boss" ? "powerup" : "catch");
    haptic("success");
  };

  const updateGull = (st: GameState, dt: number) => {
    const { W: w, waterY: wy } = dims.current;
    const skyY = wy - 170;
    if (!st.gull) {
      let mode: Gull["mode"] | null = null;
      let targetId: number | null = null;
      if (st.pointGullTimes.length && st.elapsed >= st.pointGullTimes[0]) {
        st.pointGullTimes.shift();
        mode = "points";
      } else if (st.elapsed >= st.nextFishGull) {
        const prey = st.fish.filter((f) => STEALABLE.includes(f.kind) && f.y < wy + 230 && f.x > 20 && f.x < w - 60);
        if (prey.length) {
          mode = "fish";
          targetId = prey[Math.floor(Math.random() * prey.length)].id;
          st.nextFishGull = st.elapsed + 8 + Math.random() * 5;
        } else st.nextFishGull = st.elapsed + 2;
      }
      if (mode) {
        const dir: 1 | -1 = Math.random() < 0.5 ? 1 : -1;
        st.gull = { mode, phase: "in", x: dir === 1 ? -70 : w + 10, y: skyY, dir, flap: 0, targetId, carry: null };
        if (mode === "points") pop(st, w / 2 - 30, skyY + 40, "PESCĂRUȘUL!", false);
      }
      return;
    }
    const gl = st.gull;
    gl.flap += dt * 14;
    if (gl.phase === "in") {
      let tx = st.boatX;
      let ty = wy - 120;
      if (gl.mode === "fish") {
        const f = st.fish.find((o) => o.id === gl.targetId);
        if (!f) {
          gl.phase = "out";
          return;
        }
        const hb = hitBox(f);
        tx = hb.cx;
        ty = hb.cy - 30;
      }
      const dx = tx - (gl.x + 35);
      const dy = ty - gl.y;
      const dist = Math.hypot(dx, dy);
      if (Math.abs(dx) > 4) gl.dir = dx > 0 ? 1 : -1;
      const sp = 320 * dt;
      if (dist <= sp + 6) {
        gl.phase = "out";
        if (gl.mode === "points") {
          const amt = Math.min(st.score, stealAmount());
          st.score -= amt;
          pop(st, st.boatX - 30, wy - 150, `-${amt}`, false);
          playSound("bad");
          haptic("error");
        } else {
          const f = st.fish.find((o) => o.id === gl.targetId) ?? null;
          st.fish = st.fish.filter((o) => o.id !== gl.targetId);
          gl.carry = f;
          playSound("splash");
        }
      } else {
        gl.x += (dx / dist) * sp;
        gl.y += (dy / dist) * sp;
      }
    } else {
      gl.x += gl.dir * 260 * dt;
      gl.y = Math.max(skyY - 60, gl.y - 160 * dt);
      if (gl.x < -120 || gl.x > w + 120) st.gull = null;
    }
  };

  const update = (dt: number) => {
    const st = g.current;
    const { W: w, waterY: wy, idleY: iy, bottomY: by } = dims.current;

    st.popups = st.popups.filter((p) => (p.age += dt) < 1);
    if (st.boom && (st.boom.age += dt) > 0.7) st.boom = null;
    if (st.over) return;

    st.elapsed += dt;
    st.doubleLeft = Math.max(0, st.doubleLeft - dt);
    st.time -= dt;
    if (st.time <= 0) {
      st.time = 0;
      finish(st, false);
      return;
    }

    // Scheduled visitors: a shark every 10s, a boss fish now and then.
    if (st.elapsed >= st.nextShark) {
      st.nextShark += SHARK_EVERY;
      spawn(st, "shark");
      pop(st, w / 2 - 30, wy + 40, "RECHIN!", false);
    }
    if (st.elapsed >= st.nextBoss) {
      st.nextBoss = st.elapsed + BOSS_EVERY;
      if (!st.fish.some((f) => f.kind === "boss") && st.hook.caught?.kind !== "boss") spawn(st, "boss");
    }

    const h = st.hook;
    if (h.state === "idle") {
      st.boatT += dt;
      const min = 80;
      const max = w - 100;
      st.boatX = (min + max) / 2 + Math.sin(st.boatT * 0.9) * ((max - min) / 2);
      h.x = st.boatX + 60;
      h.y = iy;
    } else if (h.state === "drop") {
      h.y += 520 * dt;
      for (const f of st.fish) {
        const { cx, cy, rx, ry } = hitBox(f);
        if (Math.abs(h.x - cx) < rx && Math.abs(h.y - cy) < ry) {
          st.fish = st.fish.filter((o) => o.id !== f.id);
          h.state = "reel";
          if (f.kind === "letter") {
            // Catching the love letter ends the round immediately.
            h.state = "reel";
            h.caught = null;
            pop(st, cx, cy - 30, "AI PRINS SCRISOAREA!", false);
            playSound("bad");
            haptic("error");
            finish(st, false);
          } else if (f.kind === "bomb") {
            st.boom = { x: cx, y: cy, age: 0 };
            st.score = Math.max(0, st.score - 20);
            pop(st, cx, cy - 30, "-20", false);
            playSound("boom");
            haptic("error");
          } else if (f.kind === "star") {
            st.score = Math.max(0, st.score - 50);
            pop(st, cx, cy - 30, "-50", false);
            playSound("bad");
            haptic("error");
          } else if (f.kind === "time") {
            st.time += 5;
            pop(st, cx, cy - 30, "+5s", true);
            playSound("powerup");
            haptic("success");
          } else if (f.kind === "double") {
            st.doubleLeft = DOUBLE_TIME;
            pop(st, cx, cy - 30, "x2!", true);
            playSound("powerup");
            haptic("success");
          } else if (f.kind === "boss") {
            h.caught = f;
            h.state = "fight";
            st.fight = { taps: 0, timer: FIGHT_WINDOW, startY: h.y };
            playSound("reel");
            haptic("error");
          } else {
            h.caught = f;
            playSound("reel");
            haptic("light");
          }
          break;
        }
      }
      if (h.state === "drop" && h.y >= by) h.state = "reel";
    } else if (h.state === "fight") {
      st.fight.timer -= dt;
      if (st.fight.timer <= 0) {
        pop(st, h.x - 20, h.y - 40, "A SCĂPAT!", false);
        playSound("bad");
        h.caught = null;
        h.state = "reel";
      }
    } else {
      h.y -= (h.caught ? (h.caught.kind === "shark" ? 220 : 300) : 650) * dt;
      if (h.y <= iy) {
        h.y = iy;
        h.state = "idle";
        if (h.caught) {
          scoreCatch(st, h.caught);
          h.caught = null;
        }
      }
    }

    const boatTarget = { x: st.boatX, y: wy };
    for (const f of st.fish) {
      if (f.kind === "shark") {
        const { w: sw, h: sh } = entityBox("shark", f.size);
        const cx = f.x + sw / 2;
        const cy = f.y + sh / 2;
        const dx = boatTarget.x - cx;
        const dy = boatTarget.y - cy;
        const dist = Math.hypot(dx, dy) || 1;
        f.x += (dx / dist) * f.speed * dt;
        f.y += (dy / dist) * f.speed * dt;
        if (Math.abs(dx) > 6) f.dir = dx > 0 ? 1 : -1;
        if (dist < 40) {
          f.kind = "bomb"; // marked for removal below
          f.size = -1;
          // Fiecare rechin provoacă exact o lovitură, apoi este eliminat.
          st.boatHp = Math.max(0, st.boatHp - 1);
          st.boom = { x: cx, y: cy, age: 0 };
          pop(st, boatTarget.x - 30, wy - 150, "-1 BARCĂ", false);
          playSound("boom");
          haptic("error");
        }
        continue;
      }
      f.x += f.dir * f.speed * dt;
      if (f.kind === "time" || f.kind === "double") f.y = f.baseY + Math.sin(st.elapsed * 3 + f.phase) * 10;
      if (f.kind === "squid") f.y = f.baseY + Math.sin(st.elapsed * 2 + f.phase) * 14;
      if (f.kind === "star") f.rot += dt * 50 * f.dir;
    }
    st.fish = st.fish.filter((f) => f.size > 0 && (f.kind === "shark" || (f.x > -entityBox(f.kind, f.size).w - 4 && f.x < w + 4)));
    if (st.boatHp <= 0) {
      st.boatHp = 0;
      finish(st, true);
      return;
    }
    while (st.fish.filter((f) => REGULAR(f.kind)).length < MAX_FISH) spawn(st);
    updateGull(st, dt);
  };

  useEffect(() => {
    let raf = 0;
    let last = performance.now();
    const step = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      update(dt);
      setFrame((f) => (f + 1) % 1000000);
      raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onTap = () => {
    const st = g.current;
    if (st.over) return;
    if (st.hook.state === "idle") {
      st.hook.state = "drop";
      playSound("splash");
    } else if (st.hook.state === "fight") {
      const { idleY: iy } = dims.current;
      st.fight.taps += 1;
      st.fight.timer = FIGHT_WINDOW;
      st.hook.y = st.fight.startY - (st.fight.startY - iy) * (st.fight.taps / BOSS_TAPS) * 0.7;
      playSound("reel");
      haptic("light");
      if (st.fight.taps >= BOSS_TAPS) st.hook.state = "reel";
    }
  };

  const restart = () => {
    g.current = makeState();
    setNewBest(false);
    setRank(null);
    setNeedsName(false);
    setShareMsg("");
  };

  const share = async () => {
    try {
      if (Platform.OS === "web" || !(await Sharing.isAvailableAsync())) {
        setShareMsg("Distribuirea merge din aplicația de pe telefon");
        return;
      }
      const uri = await captureRef(cardRef, { format: "png", quality: 1 });
      await Sharing.shareAsync(uri, { mimeType: "image/png", dialogTitle: "Provoacă-ți prietenii" });
    } catch {
      setShareMsg("Nu am putut distribui imaginea");
    }
  };

  const goHome = () => (router.canGoBack() ? router.back() : router.replace("/"));

  const st = g.current;
  const shake = st.boom ? Math.sin(st.boom.age * 70) * 8 * (1 - st.boom.age / 0.7) : 0;
  const caught = st.hook.caught;

  return (
    <View style={s.root} testID="game-screen">
      <Pressable style={s.fill} onPress={onTap} testID="game-tap-area">
        <View style={[s.fill, { transform: [{ translateX: shake }] }]}>
          <LinearGradient colors={[colors.skyTop, colors.skyBottom]} style={[s.abs, { left: 0, right: 0, top: 0, height: waterY }]} />
          <View style={[s.sun, { top: insets.top + 70, right: 36 }]} />
          <View style={[s.cloud, { top: insets.top + 96, left: 30, width: 90 }]} />
          <View style={[s.cloud, { top: insets.top + 120, left: 140, width: 60 }]} />
          <LinearGradient colors={[colors.waterTop, colors.waterDeep]} style={[s.abs, { left: 0, right: 0, top: waterY, bottom: 0 }]} />
          <View style={[s.sand, { height: insets.bottom + 26 }]} />
          {[0.12, 0.3, 0.68, 0.88].map((p, i) => (
            <View key={i} style={[s.weed, { left: W * p, height: 40 + (i % 2) * 24, bottom: insets.bottom + 14 }]} />
          ))}

          {st.fish.map((f) => (
            <View key={f.id} style={[s.abs, { left: f.x, top: f.y }]}>
              <EntitySprite size={f.size} kind={f.kind} dir={f.dir} rot={f.rot} />
            </View>
          ))}

          <View style={[s.line, { left: st.hook.x - 0.75, top: rodTipY, height: Math.max(0, st.hook.y - rodTipY) }]} />
          <View style={[s.hook, { left: st.hook.x - 6, top: st.hook.y - 2 }]} />
          {caught && (() => {
            const { w: cw, h: ch } = entityBox(caught.kind, caught.size);
            const rotate = FISHY.includes(caught.kind);
            const len = rotate ? cw : ch;
            return (
              <View
                style={[
                  s.abs,
                  { left: st.hook.x - cw / 2, top: st.hook.y + len / 2 - ch / 2 + 4 },
                  rotate && { transform: [{ rotate: "-90deg" }] },
                ]}
              >
                <EntitySprite size={caught.size} kind={caught.kind} dir={1} />
              </View>
            );
          })()}

          <PlayerOnBoat x={st.boatX} waterY={waterY} damage={BOAT_HP - st.boatHp} />

          {st.gull && (
            <View pointerEvents="none" style={[s.abs, { left: st.gull.x, top: st.gull.y }]} testID="game-seagull">
              <GullSprite size={56} dir={st.gull.dir} flap={st.gull.flap} />
              {st.gull.carry && (
                <View style={{ position: "absolute", left: 10, top: 40, transform: [{ scale: 0.7 }] }}>
                  <EntitySprite size={st.gull.carry.size} kind={st.gull.carry.kind} dir={st.gull.dir} />
                </View>
              )}
            </View>
          )}

          {st.boom && (
            <View pointerEvents="none" style={[s.abs, { left: st.boom.x - 60, top: st.boom.y - 60, width: 120, height: 120, alignItems: "center", justifyContent: "center" }]}>
              <View style={[s.boomOuter, { transform: [{ scale: 0.4 + st.boom.age * 1.6 }], opacity: 1 - st.boom.age / 0.7 }]} />
              <Text style={s.boomText}>BUM!</Text>
            </View>
          )}

          {st.popups.map((p) => (
            <Text
              key={p.id}
              style={[s.popup, { left: p.x - 30, top: p.y - p.age * 40, opacity: 1 - p.age, color: p.good ? colors.gold : colors.error }]}
            >
              {p.text}
            </Text>
          ))}
        </View>
      </Pressable>

      <View style={[s.hud, { top: insets.top + 12 }]} pointerEvents="box-none">
        <Pressable testID="game-close-button" onPress={goHome} style={s.close} hitSlop={8}>
          <Text style={s.closeText}>✕</Text>
        </Pressable>
        <View style={s.pill}>
          <Text style={s.pillLabel}>SCOR</Text>
          <Text style={s.pillValue} testID="game-score">{st.score}</Text>
        </View>
        <View style={[s.pill, st.time <= 10 && { backgroundColor: colors.error }]}>
          <Text style={[s.pillLabel, st.time <= 10 && { color: colors.onError }]}>TIMP</Text>
          <Text style={[s.pillValue, st.time <= 10 && { color: colors.onError }]} testID="game-timer">{formatTime(st.time)}</Text>
        </View>
      </View>

      <View style={[s.subHud, { top: insets.top + 64 }]} pointerEvents="none">
        <Text style={s.hpBadge} testID="game-boat-hp">
          BARCĂ {"♥".repeat(st.boatHp)}
        </Text>
        {st.doubleLeft > 0 && !st.over && (
          <Text style={s.doubleBadge} testID="game-double-badge">PUNCTE x2 · {Math.ceil(st.doubleLeft)}s</Text>
        )}
      </View>

      {st.hook.state === "fight" && !st.over && (
        <View pointerEvents="none" style={[s.hint, { top: waterY + 40 }]} testID="game-boss-fight">
          <Text style={s.fightText}>PEȘTELE BOSS! ATINGE REPEDE {st.fight.taps}/{BOSS_TAPS}</Text>
          <View style={s.fightBar}>
            <View style={[s.fightFill, { width: `${(st.fight.taps / BOSS_TAPS) * 100}%` }]} />
          </View>
        </View>
      )}

      {st.hook.state === "idle" && !st.over && st.time > GAME_TIME - 6 && st.elapsed < 6 && (
        <View pointerEvents="none" style={[s.hint, { top: waterY + 90 }]}>
          <Text style={s.hintText} testID="game-hint">Atinge oriunde ca să arunci cârligul</Text>
        </View>
      )}

      {st.over && (
        <View style={s.overlay} testID="game-over-overlay">
          <View style={s.resultCard}>
            <View ref={cardRef} collapsable={false} style={s.shareArea} testID="game-share-card">
              <Text style={s.resultKicker} testID="game-over-reason">
                <Text style={s.resultG}>G</Text>
                <Text> trebuie să mărturisesc</Text>
              </Text>
              <View style={s.faces}>
                <Image source={PLAYER_FACE} style={s.faceImg} contentFit="cover" />
                <FishSprite size={44} kind="fish" dir={-1} />
              </View>
              <Text style={s.resultScore} testID="game-final-score">{st.score}</Text>
              <Text style={s.resultBest} testID="game-best-score">
                Cel mai bun: {best}
                {st.sunk && newBest ? " · record nou!" : ""}
              </Text>
              <Text style={s.shareTag}>La peste cu Fanel · Poți să mă întreci?</Text>
            </View>
            {rank !== null && (
              <Text style={s.rankText} testID="game-rank">Locul #{rank} în clasament</Text>
            )}
            {!!shareMsg && <Text style={s.shareMsg} testID="game-share-message">{shareMsg}</Text>}
            <Pressable testID="game-play-again-button" onPress={restart} style={({ pressed }) => [s.btnPrimary, pressed && { opacity: 0.85 }]}>
              <Text style={s.btnPrimaryText}>Mai pescuiește o dată</Text>
            </Pressable>
            <View style={s.row}>
              <Pressable testID="game-share-button" onPress={share} style={({ pressed }) => [s.btnOutline, pressed && { opacity: 0.7 }]}>
                <Text style={s.btnOutlineText}>Distribuie</Text>
              </Pressable>
              <Pressable
                testID="game-leaderboard-button"
                onPress={() => router.replace("/leaderboard")}
                style={({ pressed }) => [s.btnOutline, pressed && { opacity: 0.7 }]}
              >
                <Text style={s.btnOutlineText}>{needsName ? "Intră în clasament" : "Clasament"}</Text>
              </Pressable>
            </View>
            <Pressable testID="game-home-button" onPress={goHome} style={({ pressed }) => [s.btnSecondary, pressed && { opacity: 0.7 }]}>
              <Text style={s.btnSecondaryText}>Înapoi la mal</Text>
            </Pressable>
          </View>
        </View>
      )}
    </View>
  );
}

const useStyles = makeStyles((c) => ({
  root: { flex: 1, backgroundColor: c.waterDeep, overflow: "hidden" },
  fill: { flex: 1 },
  abs: { position: "absolute" },
  sun: { position: "absolute", width: 64, height: 64, borderRadius: 32, backgroundColor: c.sun },
  cloud: { position: "absolute", height: 26, borderRadius: 13, backgroundColor: c.cloud, opacity: 0.9 },
  sand: { position: "absolute", left: 0, right: 0, bottom: 0, backgroundColor: c.sand, borderTopLeftRadius: 40, borderTopRightRadius: 40 },
  weed: { position: "absolute", width: 10, borderRadius: 5, backgroundColor: c.seaweed },
  line: { position: "absolute", width: 1.5, backgroundColor: c.line },
  hook: {
    position: "absolute",
    width: 12,
    height: 14,
    borderWidth: 3,
    borderTopWidth: 0,
    borderColor: c.hook,
    borderBottomLeftRadius: 8,
    borderBottomRightRadius: 8,
  },
  boomOuter: { position: "absolute", width: 120, height: 120, borderRadius: 60, backgroundColor: c.spark },
  boomText: { color: c.onSurfaceInverse, fontWeight: "900", fontSize: 22 },
  popup: { position: "absolute", width: 60, textAlign: "center", fontSize: 26, fontWeight: "900" },
  hud: { position: "absolute", left: 16, right: 16, flexDirection: "row", alignItems: "center", gap: 8 },
  close: { width: 44, height: 44, borderRadius: 22, backgroundColor: c.surfaceSecondary, alignItems: "center", justifyContent: "center" },
  closeText: { color: c.onSurface, fontSize: 18, fontWeight: "800" },
  pill: {
    flex: 1,
    height: 44,
    borderRadius: 22,
    backgroundColor: c.surfaceSecondary,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
  },
  pillLabel: { color: c.muted, fontSize: 11, fontWeight: "800", letterSpacing: 1.5 },
  pillValue: { color: c.onSurface, fontSize: 20, fontWeight: "900" },
  hint: { position: "absolute", left: 0, right: 0, alignItems: "center" },
  hintText: { color: c.onSurfaceInverse, backgroundColor: c.overlay, paddingHorizontal: 16, paddingVertical: 8, borderRadius: 20, fontWeight: "700", overflow: "hidden" },
  overlay: { position: "absolute", top: 0, left: 0, right: 0, bottom: 0, backgroundColor: c.overlay, alignItems: "center", justifyContent: "center", padding: 24 },
  resultCard: { width: "100%", maxWidth: 360, backgroundColor: c.surface, borderRadius: 28, padding: 20, alignItems: "center", gap: 8 },
  shareArea: { alignSelf: "stretch", alignItems: "center", backgroundColor: c.surface, paddingVertical: 8, borderRadius: 20 },
  faces: { flexDirection: "row", alignItems: "center", gap: 16, marginTop: 8 },
  faceImg: { width: 52, height: 52, borderRadius: 26, borderWidth: 2, borderColor: c.shirt },
  shareTag: { color: c.brandSecondary, fontWeight: "800", fontSize: 13 },
  rankText: { color: c.success, fontWeight: "800", fontSize: 15 },
  shareMsg: { color: c.muted, fontSize: 13, textAlign: "center" },
  row: { flexDirection: "row", gap: 8, alignSelf: "stretch" },
  btnOutline: { flex: 1, height: 48, borderRadius: 24, borderWidth: 1.5, borderColor: c.brandPrimary, alignItems: "center", justifyContent: "center" },
  btnOutlineText: { color: c.brandPrimary, fontWeight: "800", fontSize: 14 },
  doubleBadge: { color: c.onBrandPrimary, backgroundColor: c.brandPrimary, paddingHorizontal: 14, paddingVertical: 6, borderRadius: 16, fontWeight: "900", overflow: "hidden" },
  subHud: { position: "absolute", left: 16, right: 16, flexDirection: "row", alignItems: "center", gap: 8 },
  hpBadge: { color: c.error, backgroundColor: c.surfaceSecondary, paddingHorizontal: 12, paddingVertical: 6, borderRadius: 16, fontWeight: "900", overflow: "hidden" },
  fightText: { color: c.onBrandPrimary, backgroundColor: c.boss, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 16, fontWeight: "900", overflow: "hidden" },
  fightBar: { width: 200, height: 10, borderRadius: 5, backgroundColor: c.overlay, marginTop: 8, overflow: "hidden" },
  fightFill: { height: 10, backgroundColor: c.gold },
  resultKicker: { color: c.brandPrimary, fontWeight: "900", letterSpacing: 1, fontSize: 14 },
  resultG: { fontWeight: "900", textDecorationLine: "underline" },
  resultScore: { color: c.onSurface, fontWeight: "900", fontSize: 72, lineHeight: 80 },
  resultBest: { color: c.muted, fontWeight: "700", fontSize: 16, marginBottom: 4 },
  btnPrimary: { alignSelf: "stretch", height: 56, borderRadius: 28, backgroundColor: c.brandPrimary, alignItems: "center", justifyContent: "center" },
  btnPrimaryText: { color: c.onBrandPrimary, fontWeight: "900", fontSize: 17 },
  btnSecondary: { alignSelf: "stretch", height: 48, alignItems: "center", justifyContent: "center" },
  btnSecondaryText: { color: c.onSurfaceSecondary, fontWeight: "700", fontSize: 15 },
}));
