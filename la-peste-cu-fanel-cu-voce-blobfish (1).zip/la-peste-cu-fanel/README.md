# La peste cu Fanel

A Romanian-language arcade fishing game built with Expo Router, React Native and a small FastAPI/MongoDB leaderboard service.

## What's included

- 60-second fishing rounds with a swaying boat, tap-to-drop hook, animated fish and score popups.
- Nine user-supplied face crops used for the fisherman, fish/boss, bomb, starfish, gull, blobfish, shark, snail and squid.
- Score rules: regular fish +10…+30, gold +50, green +100, squid +50…+100, rare snail +500, blobfish +1; bomb -20 and starfish -50.
- +5-second and x2-for-10-seconds power-ups, boss tap challenge, shark boat damage and seagull theft events.
- Haptics, sound effects, looping original background music, local best-score storage and score-card sharing on supported phones.
- Romanian home and game-over screens, plus an online leaderboard with case-insensitive player names.

## Project layout

```text
backend/                 FastAPI API, MongoDB score collection and pytest tests
frontend/
  app/                   Expo Router home, game and leaderboard screens
  src/game/              Sprites, creature rendering and sounds
  src/utils/storage/     AsyncStorage / SecureStore wrapper
  assets/images/         Cropped face photos and app artwork
  assets/sounds/         Generated game sound effects and music
  scripts/               Reset and install-guard scripts
tests/                   Root test package placeholder
test_reports/            Supplied prior test notes
```

## Run locally

### 1. Backend

Install MongoDB and Python dependencies, then create `backend/.env` from `backend/.env.example`.

```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn server:app --host 0.0.0.0 --port 8001 --reload
```

The backend expects MongoDB at the URL in `MONGO_URL`. The API root is `GET /api/`; the leaderboard routes are `POST /api/scores` and `GET /api/leaderboard`.

### 2. Expo frontend

Create `frontend/.env` from `frontend/.env.example` and set `EXPO_PUBLIC_BACKEND_URL` to a URL reachable by the device/browser. Do not use `localhost` for a phone build; use the LAN or deployed API URL.

```bash
cd frontend
yarn install
yarn start
```

Use `yarn web` for the browser preview, `yarn android` for an Android emulator/device or `yarn ios` for the iOS simulator. Expo Go support depends on the installed Expo Go SDK matching the project.

## Gameplay controls

Tap anywhere in the water/playfield to drop the hook. Tap repeatedly during the boss encounter to win the catch. The round ends after 60 seconds or when the boat loses all four health points.

## Important configuration

- `frontend/.env` is intentionally not included; copy `.env.example` and set your backend URL.
- `backend/.env` is intentionally not included; copy `.env.example` and set your MongoDB connection.
- `best_score`, `player_name` and `music_on` are saved locally on the device/browser.
- The leaderboard already supports online scores through the FastAPI backend. For it to be genuinely shared between phones, the backend must be deployed publicly with MongoDB, and `EXPO_PUBLIC_BACKEND_URL` must be set to that public API URL when building the app. This repository does not currently contain a deployed backend URL or database credentials, so online sharing cannot be activated by code changes alone. Without that configuration, the game still works and the leaderboard reports that syncing is unavailable.
- Sharing a score image is supported on native devices where the share sheet is available. The web preview reports that sharing is phone-only.

## Checks

The source message included prior reports showing 13/13 backend API tests passing and a 95% frontend flow pass rate for an earlier project revision. Those historical reports are kept separately in `test_reports/`; this newly assembled ZIP has not been run through a complete Expo install/build in this environment.
