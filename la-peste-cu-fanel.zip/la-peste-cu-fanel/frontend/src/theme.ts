import { useMemo } from "react";
import { Appearance, StyleSheet, useColorScheme } from "react-native";

export type ColorScheme = "light" | "dark";

const light = {
  surface: "#FFF8EC", onSurface: "#0B2545", surfaceSecondary: "#FFFFFF", onSurfaceSecondary: "#1B3A5C", surfaceTertiary: "#E8F6FA", onSurfaceTertiary: "#3E5C76", surfaceInverse: "#0B2545", onSurfaceInverse: "#FFFFFF", muted: "#6B819A",
  brand: "#FF6B35", onBrand: "#FFFFFF", brandPrimary: "#FF6B35", onBrandPrimary: "#FFFFFF", brandSecondary: "#13A3B4", onBrandSecondary: "#FFFFFF", brandTertiary: "#FFE3D3", onBrandTertiary: "#7A2E0E",
  success: "#1F9D55", onSuccess: "#FFFFFF", warning: "#E0A100", onWarning: "#FFFFFF", error: "#D7263D", onError: "#FFFFFF", info: "#1D6FD8", onInfo: "#FFFFFF",
  border: "#D9E6EE", borderStrong: "#9FB7C9", divider: "#E5EDF2",
  skyTop: "#8FD3FF", skyBottom: "#FFE2B8", sun: "#FFD166", cloud: "#FFFFFF", waterTop: "#2EC4D6", waterDeep: "#0A3A66", sand: "#E9C98B", seaweed: "#1E8C6E", boat: "#B5562E", boatDark: "#7E3519", shirt: "#5A2340", skin: "#C68B63", rod: "#3B2A1A", line: "#F4F4F4", hook: "#C9D2DA", fishBody: "#FF8C61", fishFin: "#E5603A", gold: "#FFC93C", goldFin: "#E5A100", bomb: "#232323", green: "#2ECC71", greenFin: "#1E9E55", star: "#9B4DCA", starDark: "#6C2E8A", powerBubble: "rgba(191, 243, 250, 0.85)", squid: "#FFFFFF", squidEdge: "#C9D4DE", snailShell: "#A0522D", snailShellLight: "#D2905A", snailBody: "#E8C99A", blob: "#F4A6B8", blobDark: "#D9788F", shark: "#7D8B99", sharkBelly: "#C7D0D9", sharkDark: "#55606B", boss: "#E63946", bossFin: "#9D0208", gullBody: "#FFFFFF", gullWing: "#A7B4C0", beak: "#FF9F1C", crack: "#2B1408", spark: "#FF9F1C", bubble: "#BFF3FA", overlay: "rgba(5, 25, 45, 0.55)",
};

export type ThemeColors = typeof light;
export const defaultScheme = "light" satisfies ColorScheme;
export const themes: { light: ThemeColors; dark?: ThemeColors } = { light };

export function setColorScheme(scheme: ColorScheme | null) {
  Appearance.setColorScheme?.(scheme ?? "unspecified");
}
setColorScheme(themes.dark ? null : defaultScheme);

export function useTheme(): { scheme: ColorScheme; colors: ThemeColors } {
  const system = useColorScheme();
  const scheme: ColorScheme = (system === "light" || system === "dark") && themes[system] ? system : defaultScheme;
  return { scheme, colors: themes[scheme] ?? themes.light };
}

export function makeStyles<T extends StyleSheet.NamedStyles<T> | StyleSheet.NamedStyles<any>>(
  factory: (colors: ThemeColors) => T & StyleSheet.NamedStyles<any>,
): () => T {
  return function useStyles(): T {
    const { colors } = useTheme();
    return useMemo(() => StyleSheet.create(factory(colors)), [colors]);
  };
}
