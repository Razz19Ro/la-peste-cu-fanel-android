const BASE = process.env.EXPO_PUBLIC_BACKEND_URL?.replace(/\/$/, "");

export type ScoreEntry = { name: string; score: number; updated_at: string };
export type ScoreResult = ScoreEntry & { rank: number };

function requireBase() {
  if (!BASE) throw new Error("EXPO_PUBLIC_BACKEND_URL nu este configurat");
  return BASE;
}

export async function submitScore(name: string, score: number): Promise<ScoreResult> {
  const res = await fetch(`${requireBase()}/api/scores`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name, score }),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

export async function getLeaderboard(): Promise<ScoreEntry[]> {
  const res = await fetch(`${requireBase()}/api/leaderboard?limit=50`);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}
