import { AudioPlayer, createAudioPlayer, setAudioModeAsync } from "expo-audio";
import { storage } from "@/src/utils/storage";

const SOURCES = {
  splash: require("../../assets/sounds/splash.wav"),
  reel: require("../../assets/sounds/reel.wav"),
  catch: require("../../assets/sounds/catch.wav"),
  boom: require("../../assets/sounds/boom.wav"),
  powerup: require("../../assets/sounds/powerup.wav"),
  bad: require("../../assets/sounds/bad.wav"),
  chant: require("../../assets/sounds/chant.wav"),
};
export type SoundName = keyof typeof SOURCES;
const players: Partial<Record<SoundName, AudioPlayer>> = {};
let music: AudioPlayer | null = null;
let musicOn = true;
let ready = false;
let resumeTimer: ReturnType<typeof setTimeout> | null = null;

export async function getMusicOn(): Promise<boolean> {
  return (await storage.getItem("music_on", true as boolean)) !== false;
}

export function initSounds() {
  if (ready) return;
  ready = true;
  setAudioModeAsync({ playsInSilentMode: true }).catch(() => {});
  (Object.keys(SOURCES) as SoundName[]).forEach((k) => {
    try { players[k] = createAudioPlayer(SOURCES[k]); } catch { /* audio may be unavailable in a preview */ }
  });
  try {
    music = createAudioPlayer(require("../../assets/sounds/music.wav"));
    music.loop = true;
    music.volume = 0.35;
  } catch { /* ignored */ }
  getMusicOn().then((on) => {
    musicOn = on;
    if (on) safePlay(music);
  });
}

function safePlay(p: AudioPlayer | null | undefined) {
  try { p?.play(); } catch { /* ignore playback failures */ }
}

export function setMusicOn(on: boolean) {
  musicOn = on;
  void storage.setItem("music_on", on);
  try { if (on) music?.play(); else music?.pause(); } catch { /* ignore */ }
}

export function playSound(name: SoundName) {
  const p = players[name];
  if (!p) return;
  try { p.seekTo(0)?.catch?.(() => {}); p.play(); } catch { /* ignore */ }
}

export function playChant() {
  playSound("chant");
  if (!music || !musicOn) return;
  try { music.pause(); } catch { /* ignore */ }
  if (resumeTimer) clearTimeout(resumeTimer);
  resumeTimer = setTimeout(() => { if (musicOn) safePlay(music); }, 3400);
}
