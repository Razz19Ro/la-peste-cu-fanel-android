import { Image } from "expo-image";
import { View } from "react-native";

import { useTheme } from "@/src/theme";

export const SQUID_FACE = require("../../assets/images/squid-face.png");
export const SNAIL_FACE = require("../../assets/images/snail-face.png");
export const BLOB_FACE = require("../../assets/images/blob-face.png");
export const SHARK_FACE = require("../../assets/images/shark-face.png");
export const GULL_FACE = require("../../assets/images/gull-face.png");

const face = (d: number, border: string) => ({ width: d, height: d, borderRadius: d / 2, borderWidth: 2, borderColor: border });

export function SquidSprite({ size }: { size: number }) {
  const { colors } = useTheme();
  const w = size * 0.8;
  return (
    <View style={{ width: w, height: size * 1.25 }}>
      {[0.1, 0.27, 0.44, 0.61, 0.78].map((p, i) => (
        <View key={p} style={{ position: "absolute", left: w * p - size * 0.04, top: size * 0.68, width: size * 0.09, height: size * (i % 2 ? 0.55 : 0.48), borderRadius: size * 0.05, backgroundColor: colors.squid, borderWidth: 1, borderColor: colors.squidEdge, transform: [{ rotate: `${(i - 2) * 8}deg` }] }} />
      ))}
      <View style={{ position: "absolute", left: 0, top: 0, width: w, height: size * 0.82, borderTopLeftRadius: w / 2, borderTopRightRadius: w / 2, borderBottomLeftRadius: size * 0.18, borderBottomRightRadius: size * 0.18, backgroundColor: colors.squid, borderWidth: 1.5, borderColor: colors.squidEdge, alignItems: "center", justifyContent: "center" }}>
        <Image source={SQUID_FACE} style={[face(size * 0.56, colors.squidEdge), { marginTop: size * 0.08 }]} contentFit="cover" />
      </View>
    </View>
  );
}

export function SnailSprite({ size, dir }: { size: number; dir: 1 | -1 }) {
  const { colors } = useTheme();
  const shell = size * 0.82;
  return (
    <View style={{ width: size * 1.3, height: size, transform: [{ scaleX: dir }] }}>
      <View style={{ position: "absolute", left: 0, top: size * 0.66, width: size * 1.28, height: size * 0.3, borderRadius: size * 0.15, backgroundColor: colors.snailBody }} />
      {[0.98, 1.12].map((p) => (
        <View key={p} style={{ position: "absolute", left: size * p, top: size * 0.4, width: size * 0.06, height: size * 0.3, borderRadius: size * 0.03, backgroundColor: colors.snailBody, transform: [{ rotate: p > 1 ? "20deg" : "5deg" }] }} />
      ))}
      <View style={{ position: "absolute", left: size * 0.1, top: 0, width: shell, height: shell, borderRadius: shell / 2, backgroundColor: colors.snailShell, borderWidth: size * 0.07, borderColor: colors.snailShellLight, alignItems: "center", justifyContent: "center" }}>
        <Image source={SNAIL_FACE} style={[face(shell * 0.68, colors.snailShell), { transform: [{ scaleX: dir }] }]} contentFit="cover" />
      </View>
    </View>
  );
}

export function BlobSprite({ size }: { size: number }) {
  const { colors } = useTheme();
  return (
    <View style={{ width: size * 1.15, height: size * 0.9, borderTopLeftRadius: size * 0.6, borderTopRightRadius: size * 0.6, borderBottomLeftRadius: size * 0.35, borderBottomRightRadius: size * 0.35, backgroundColor: colors.blob, borderWidth: 2, borderColor: colors.blobDark, alignItems: "center", justifyContent: "center" }}>
      <Image source={BLOB_FACE} style={face(size * 0.66, colors.blobDark)} contentFit="cover" />
    </View>
  );
}

export function SharkSprite({ size, dir }: { size: number; dir: 1 | -1 }) {
  const { colors } = useTheme();
  const d = size * 0.6;
  return (
    <View style={{ width: size * 2, height: size * 0.85, transform: [{ scaleX: dir }] }}>
      <View style={{ position: "absolute", left: 0, top: size * 0.1, width: 0, height: 0, borderTopWidth: size * 0.3, borderBottomWidth: size * 0.3, borderLeftWidth: size * 0.4, borderTopColor: "transparent", borderBottomColor: "transparent", borderLeftColor: colors.sharkDark }} />
      <View style={{ position: "absolute", left: size * 0.75, top: -size * 0.12, width: 0, height: 0, borderBottomWidth: size * 0.34, borderLeftWidth: size * 0.3, borderRightWidth: size * 0.08, borderLeftColor: "transparent", borderRightColor: "transparent", borderBottomColor: colors.sharkDark }} />
      <View style={{ position: "absolute", left: size * 0.3, top: size * 0.16, width: size * 1.65, height: size * 0.62, borderRadius: size, backgroundColor: colors.shark, overflow: "hidden" }}>
        <View style={{ position: "absolute", left: 0, right: 0, bottom: 0, height: size * 0.22, backgroundColor: colors.sharkBelly }} />
      </View>
      <Image source={SHARK_FACE} style={[face(d, colors.sharkDark), { position: "absolute", right: 0, top: size * 0.12, transform: [{ scaleX: dir }] }]} contentFit="cover" />
    </View>
  );
}

export function GullSprite({ size, dir, flap }: { size: number; dir: 1 | -1; flap: number }) {
  const { colors } = useTheme();
  const wing = Math.sin(flap) * 35;
  return (
    <View style={{ width: size * 1.4, height: size, transform: [{ scaleX: dir }] }}>
      <View style={{ position: "absolute", left: size * 0.2, top: size * 0.25, width: size * 0.75, height: size * 0.18, borderRadius: size * 0.1, backgroundColor: colors.gullWing, transform: [{ rotate: `${-wing}deg` }] }} />
      <View style={{ position: "absolute", left: size * 0.1, top: size * 0.4, width: size * 0.85, height: size * 0.4, borderRadius: size * 0.25, backgroundColor: colors.gullBody }} />
      <View style={{ position: "absolute", left: size * 0.3, top: size * 0.45, width: size * 0.65, height: size * 0.16, borderRadius: size * 0.1, backgroundColor: colors.gullWing, transform: [{ rotate: `${wing}deg` }] }} />
      <View style={{ position: "absolute", right: 0, top: size * 0.4, width: 0, height: 0, borderTopWidth: size * 0.08, borderBottomWidth: size * 0.08, borderLeftWidth: size * 0.2, borderTopColor: "transparent", borderBottomColor: "transparent", borderLeftColor: colors.beak }} />
      <Image source={GULL_FACE} style={[face(size * 0.5, colors.gullWing), { position: "absolute", right: size * 0.14, top: size * 0.18, transform: [{ scaleX: dir }] }]} contentFit="cover" />
    </View>
  );
}
