# Supplied face assignments

The following PNGs are crops made from the nine-photo montage supplied with the project:

1. `star-face.png` — purple starfish
2. `bomb-face.png` — bomb
3. `player-face.png` — fisherman / player on the boat
4. `fish-face.png` — ordinary fish and boss fish
5. `gull-face.png` — seagull
6. `blob-face.png` — blobfish
7. `shark-face.png` — shark
8. `snail-face.png` — snail
9. `squid-face.png` — squid
