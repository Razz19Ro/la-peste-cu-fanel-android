import { useCallback, useEffect, useState } from "react";
import { ActivityIndicator, FlatList, Pressable, RefreshControl, Text, TextInput, View } from "react-native";
import { useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { makeStyles, useTheme } from "@/src/theme";
import { storage } from "@/src/utils/storage";
import { getLeaderboard, type ScoreEntry, submitScore } from "@/src/api";

export default function Leaderboard() {
  const s = useStyles();
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [name, setName] = useState("");
  const [savedName, setSavedName] = useState("");
  const [entries, setEntries] = useState<ScoreEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState("");
  const [msg, setMsg] = useState("");
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    try {
      setError("");
      setEntries(await getLeaderboard());
    } catch {
      setError("Nu am putut încărca clasamentul. Verifică internetul.");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    storage.getItem("player_name", "").then((v) => {
      const n = String(v || "");
      setName(n);
      setSavedName(n);
    });
    load();
  }, [load]);

  const save = async () => {
    const n = name.trim();
    if (!n) {
      setMsg("Scrie un nume mai întâi");
      return;
    }
    setSaving(true);
    try {
      await storage.setItem("player_name", n);
      setSavedName(n);
      const best = Number(await storage.getItem("best_score", 0)) || 0;
      const r = await submitScore(n, best);
      setMsg(`Salvat! Ești pe locul #${r.rank}`);
      await load();
    } catch {
      setMsg("Numele a fost salvat pe dispozitiv, dar nu am putut sincroniza scorul.");
    } finally {
      setSaving(false);
    }
  };

  const goBack = () => (router.canGoBack() ? router.back() : router.replace("/"));

  return (
    <View style={[s.root, { paddingTop: insets.top + 8 }]} testID="leaderboard-screen">
      <View style={s.header}>
        <Pressable testID="leaderboard-back-button" onPress={goBack} style={s.back} hitSlop={8}>
          <Text style={s.backText}>‹</Text>
        </Pressable>
        <Text style={s.title}>Clasament</Text>
      </View>

      <View style={s.nameCard}>
        <Text style={s.label}>NUMELE TĂU</Text>
        <View style={s.nameRow}>
          <TextInput
            testID="leaderboard-name-input"
            value={name}
            onChangeText={setName}
            placeholder="ex. Fănel"
            placeholderTextColor={colors.muted}
            maxLength={20}
            style={s.input}
            returnKeyType="done"
            onSubmitEditing={save}
          />
          <Pressable testID="leaderboard-save-button" onPress={save} disabled={saving} style={({ pressed }) => [s.save, pressed && { opacity: 0.85 }]}>
            {saving ? <ActivityIndicator color={colors.onBrandPrimary} /> : <Text style={s.saveText}>Salvează</Text>}
          </Pressable>
        </View>
        {!!msg && <Text style={s.msg} testID="leaderboard-message">{msg}</Text>}
      </View>

      {loading ? (
        <ActivityIndicator style={{ marginTop: 32 }} color={colors.brandPrimary} testID="leaderboard-loading" />
      ) : (
        <FlatList
          data={entries}
          keyExtractor={(e) => e.name}
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: insets.bottom + 24, gap: 8 }}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); load(); }} />}
          ListEmptyComponent={
            <Text style={s.empty} testID="leaderboard-empty">{error || "Încă nu e nimeni în clasament. Fii primul!"}</Text>
          }
          renderItem={({ item, index }) => {
            const me = item.name.toLowerCase() === savedName.trim().toLowerCase();
            return (
              <View style={[s.item, me && s.itemMe]} testID={`leaderboard-row-${index + 1}`}>
                <Text style={[s.rank, index < 3 && { color: colors.brandPrimary }]}>{index + 1}</Text>
                <Text style={s.name} numberOfLines={1}>{item.name}{me ? " (tu)" : ""}</Text>
                <Text style={s.score}>{item.score}</Text>
              </View>
            );
          }}
        />
      )}
    </View>
  );
}

const useStyles = makeStyles((c) => ({
  root: { flex: 1, backgroundColor: c.surface },
  header: { flexDirection: "row", alignItems: "center", paddingHorizontal: 16, gap: 8, height: 56 },
  back: { width: 44, height: 44, borderRadius: 22, backgroundColor: c.surfaceTertiary, alignItems: "center", justifyContent: "center" },
  backText: { color: c.onSurface, fontSize: 28, fontWeight: "700", marginTop: -3 },
  title: { color: c.onSurface, fontSize: 28, fontWeight: "900" },
  nameCard: { margin: 16, padding: 16, borderRadius: 20, backgroundColor: c.surfaceSecondary, gap: 8, borderWidth: 1, borderColor: c.border },
  label: { color: c.muted, fontWeight: "800", letterSpacing: 1.5, fontSize: 12 },
  nameRow: { flexDirection: "row", gap: 8 },
  input: { flex: 1, minWidth: 0, height: 48, borderRadius: 14, backgroundColor: c.surfaceTertiary, paddingHorizontal: 14, color: c.onSurface, fontSize: 16, fontWeight: "600" },
  save: { height: 48, paddingHorizontal: 18, borderRadius: 14, backgroundColor: c.brandPrimary, alignItems: "center", justifyContent: "center" },
  saveText: { color: c.onBrandPrimary, fontWeight: "900" },
  msg: { color: c.onSurfaceSecondary, fontWeight: "600" },
  empty: { color: c.muted, textAlign: "center", marginTop: 32, fontSize: 15 },
  item: { flexDirection: "row", alignItems: "center", height: 56, paddingHorizontal: 16, borderRadius: 16, backgroundColor: c.surfaceSecondary, gap: 12 },
  itemMe: { borderWidth: 1.5, borderColor: c.brandPrimary },
  rank: { width: 28, color: c.muted, fontWeight: "900", fontSize: 18 },
  name: { flex: 1, color: c.onSurface, fontWeight: "700", fontSize: 16 },
  score: { color: c.onSurface, fontWeight: "900", fontSize: 18 },
}));
