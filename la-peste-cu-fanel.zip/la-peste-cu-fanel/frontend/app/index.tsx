import { useCallback, useEffect, useState } from "react";
import { Pressable, ScrollView, Text, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Image } from "expo-image";
import { useFocusEffect, useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Animated, { useAnimatedStyle, useSharedValue, withRepeat, withSequence, withTiming, Easing } from "react-native-reanimated";

import { makeStyles, useTheme } from "@/src/theme";
import { storage } from "@/src/utils/storage";
import { EntitySprite, FishSprite, type Kind, PLAYER_FACE } from "@/src/game/sprites";
import { GullSprite } from "@/src/game/creatures";
import { getMusicOn, initSounds, setMusicOn } from "@/src/game/sounds";

const RULES: { kind: Kind | "gull"; text: string; size?: number }[] = [
  { kind: "fish", text: "+10…+30" },
  { kind: "gold", text: "Auriu +50" },
  { kind: "green", text: "Verde +100" },
  { kind: "squid", text: "Calamar +50…+100" },
  { kind: "snail", text: "Melc rar +500" },
  { kind: "blob", text: "Blobfish +1 și cântare" },
  { kind: "boss", text: "Boss +300, atinge repede", size: 22 },
  { kind: "shark", text: "Rechin +50, apără barca", size: 18 },
  { kind: "star", text: "Stea de mare -50" },
  { kind: "bomb", text: "Bombă -20" },
  { kind: "double", text: "Bonus +5s sau x2" },
  { kind: "gull", text: "Pescărușul fură" },
];

export default function Home() {
  const s = useStyles();
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [best, setBest] = useState(0);
  const [music, setMusic] = useState(true);
  const bob = useSharedValue(0);

  useEffect(() => {
    initSounds();
    getMusicOn().then(setMusic);
  }, []);

  const toggleMusic = () => {
    const next = !music;
    setMusic(next);
    setMusicOn(next);
  };

  useFocusEffect(
    useCallback(() => {
      storage.getItem("best_score", 0).then((v) => setBest(Number(v) || 0));
    }, []),
  );

  useEffect(() => {
    bob.value = withRepeat(
      withSequence(
        withTiming(1, { duration: 1400, easing: Easing.inOut(Easing.sin) }),
        withTiming(0, { duration: 1400, easing: Easing.inOut(Easing.sin) }),
      ),
      -1,
    );
  }, [bob]);

  const fishAnim = useAnimatedStyle(() => ({
    transform: [{ translateY: bob.value * 14 }, { rotate: `${bob.value * 6 - 3}deg` }],
  }));

  return (
    <LinearGradient colors={[colors.skyTop, colors.waterTop, colors.waterDeep]} locations={[0, 0.45, 1]} style={s.root}>
      <ScrollView contentContainerStyle={[s.content, { paddingTop: insets.top + 24, paddingBottom: insets.bottom + 24 }]} showsVerticalScrollIndicator={false}>
        <View>
          <View style={s.topRow}>
            <Text style={s.kicker}>UN SPORT FOARTE SERIOS</Text>
            <Pressable
              testID="home-music-toggle"
              onPress={toggleMusic}
              hitSlop={8}
              style={({ pressed }) => [s.musicBtn, !music && s.musicOff, pressed && { opacity: 0.8 }]}
            >
              <Text style={[s.musicText, !music && s.musicTextOff]}>{music ? "♪ Muzică: Pornită" : "♪ Muzică: Oprită"}</Text>
            </Pressable>
          </View>
          <Text style={s.title} testID="home-title">La peste{"\n"}cu Fanel</Text>
        </View>

        <View style={s.hero}>
          <Image source={PLAYER_FACE} style={s.player} contentFit="cover" transition={180} />
          <Animated.View style={fishAnim}>
            <FishSprite size={110} kind="fish" dir={-1} />
          </Animated.View>
        </View>

        <View style={s.card}>
          <View style={s.bestRow}>
            <Text style={s.bestLabel}>CEL MAI BUN SCOR</Text>
            <Text style={s.bestValue} testID="home-best-score">{best}</Text>
          </View>
          <View style={s.rules}>
            {RULES.map((r) => (
              <View style={s.rule} key={r.text}>
                <View style={s.ruleIcon}>
                  {r.kind === "gull" ? (
                    <GullSprite size={24} dir={1} flap={0.6} />
                  ) : (
                    <EntitySprite size={r.size ?? 20} kind={r.kind} dir={1} />
                  )}
                </View>
                <Text style={s.ruleText} numberOfLines={2}>{r.text}</Text>
              </View>
            ))}
          </View>
          <Pressable
            testID="home-play-button"
            onPress={() => router.push("/game")}
            style={({ pressed }) => [s.play, pressed && { transform: [{ scale: 0.97 }], opacity: 0.9 }]}
          >
            <Text style={s.playText}>Aruncă undița · 60s</Text>
          </Pressable>
          <Pressable
            testID="home-leaderboard-button"
            onPress={() => router.push("/leaderboard")}
            style={({ pressed }) => [s.secondary, pressed && { opacity: 0.7 }]}
          >
            <Text style={s.secondaryText}>Clasament</Text>
          </Pressable>
        </View>
      </ScrollView>
    </LinearGradient>
  );
}

const useStyles = makeStyles((c) => ({
  root: { flex: 1 },
  content: { flexGrow: 1, paddingHorizontal: 24, justifyContent: "space-between", gap: 12 },
  kicker: { color: c.onSurface, fontWeight: "800", letterSpacing: 2, fontSize: 12, opacity: 0.7 },
  title: { color: c.onSurface, fontSize: 48, lineHeight: 52, fontWeight: "900", letterSpacing: -1.5, marginTop: 8 },
  hero: { height: 150, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  player: { width: 110, height: 110, borderRadius: 55, borderWidth: 4, borderColor: c.surfaceSecondary, backgroundColor: c.surfaceTertiary },
  card: { backgroundColor: c.surfaceSecondary, borderRadius: 28, padding: 20, gap: 14 },
  bestRow: { flexDirection: "row", alignItems: "baseline", justifyContent: "space-between" },
  bestLabel: { color: c.muted, fontWeight: "800", letterSpacing: 1.5, fontSize: 12 },
  bestValue: { color: c.onSurface, fontWeight: "900", fontSize: 32 },
  rules: { flexDirection: "row", flexWrap: "wrap", rowGap: 8 },
  rule: { width: "50%", flexDirection: "row", alignItems: "center", gap: 6, paddingRight: 4 },
  ruleIcon: { width: 40, height: 30, alignItems: "center", justifyContent: "center", overflow: "hidden" },
  ruleText: { flex: 1, color: c.onSurfaceSecondary, fontSize: 12, fontWeight: "700" },
  topRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 8 },
  musicBtn: { height: 36, paddingHorizontal: 12, borderRadius: 18, backgroundColor: c.surfaceSecondary, justifyContent: "center" },
  musicOff: { backgroundColor: c.overlay },
  musicText: { color: c.onSurface, fontWeight: "800", fontSize: 12 },
  musicTextOff: { color: c.onSurfaceInverse },
  secondary: { height: 44, alignItems: "center", justifyContent: "center", marginTop: -6 },
  secondaryText: { color: c.brandSecondary, fontSize: 16, fontWeight: "800" },
  play: { backgroundColor: c.brandPrimary, height: 58, borderRadius: 29, alignItems: "center", justifyContent: "center" },
  playText: { color: c.onBrandPrimary, fontSize: 18, fontWeight: "900", letterSpacing: 0.5 },
}));
