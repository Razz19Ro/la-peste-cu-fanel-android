#!/usr/bin/env node
const fs = require("fs");
const path = require("path");
const readline = require("readline");
const root = process.cwd();
const oldDirs = ["app", "components", "hooks", "constants", "scripts"];
const exampleDir = "app-example";
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const moveDirectories = async (answer) => {
  try {
    if (answer === "y") await fs.promises.mkdir(path.join(root, exampleDir), { recursive: true });
    for (const dir of oldDirs) {
      const src = path.join(root, dir);
      if (!fs.existsSync(src)) continue;
      if (answer === "y") await fs.promises.rename(src, path.join(root, exampleDir, dir));
      else await fs.promises.rm(src, { recursive: true, force: true });
    }
    const appDir = path.join(root, "app");
    await fs.promises.mkdir(appDir, { recursive: true });
    await fs.promises.writeFile(path.join(appDir, "index.tsx"), 'import { Text, View } from "react-native";\nexport default function Index() { return <View style={{ flex:  1, justifyContent: "center", alignItems: "center" }}><Text>Edit app/index.tsx to edit this screen.</Text></View>; }\n');
    await fs.promises.writeFile(path.join(appDir, "_layout.tsx"), 'import { Stack } from "expo-router";\nexport default function RootLayout() { return <Stack />; }\n');
    console.log("Project reset complete.");
  } catch (error) { console.error(`Reset failed: ${error.message}`); }
};
rl.question("Move existing app files to app-example instead of deleting them? (Y/n): ", (answer) => {
  const value = answer.trim().toLowerCase() || "y";
  if (value === "y" || value === "n") moveDirectories(value).finally(() => rl.close());
  else { console.log("Please enter Y or n."); rl.close(); }
});
