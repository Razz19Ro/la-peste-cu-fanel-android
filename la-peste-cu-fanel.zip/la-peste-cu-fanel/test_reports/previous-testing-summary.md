# Previously supplied test reports

These are summaries transcribed from the user's supplied project reports; they are historical context, not fresh tests of the assembled ZIP.

## Earlier frontend + backend run

- Backend leaderboard tests: 13/13 passed.
- Frontend preview success rate: 95%.
- Reported flows included home screen, 60-second timer, fish catches, bomb penalties, game-over state, play-again, best-score persistence and home navigation.
- One issue in an earlier revision was direct-opening `/game` then pressing close. The source later supplied in this conversation uses `router.canGoBack() ? router.back() : router.replace("/")`.

## Later feature-complete frontend run

- Reported main game mechanics: gold +50, green +100, starfish -50, bomb -20, +5-second bubble, x2 bubble, leaderboard save and auto-submit.
- Earlier report noted leaderboard input overflow and async late-result edge cases. This reconstruction adds `minWidth: 0` to the name input; the late-result edge case remains worth checking in a real runtime.
- Native audio and native share sheet could not be verified by the supplied browser tests.
