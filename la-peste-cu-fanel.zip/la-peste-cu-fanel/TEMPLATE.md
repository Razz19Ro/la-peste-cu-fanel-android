# Project notes

This is an Expo Router project with strict TypeScript and a FastAPI backend.

- Routes live under `frontend/app/`; non-screen code lives in `frontend/src/`.
- The `@/*` alias points to the frontend root. For example, use `@/src/theme`.
- All UI is React Native. Images use `expo-image`; motion uses Reanimated.
- Use `storage` from `@/src/utils/storage` for local key/value storage. Do not import AsyncStorage or SecureStore directly in app screens.
- Configure the API with `EXPO_PUBLIC_BACKEND_URL`. The app must use an absolute URL so the same bundle works on a phone and in the browser.
- Backend routes must be registered on the `/api` router, use async Motor calls and omit Mongo `_id` values from responses.
- Keep `backend/pytest.ini` and the Expo project scripts/configuration consistent with the installed dependencies.

See `README.md` for run instructions and `backend/tests/test_leaderboard.py` for the API contract.
