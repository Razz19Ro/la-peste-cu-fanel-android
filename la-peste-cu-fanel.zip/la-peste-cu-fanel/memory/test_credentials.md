# Test credentials

No authentication or seeded test accounts are required for this game. The leaderboard uses a player display name entered in the app.
