import asyncio
import logging
import os
import uuid
from contextlib import suppress
from datetime import datetime, timezone
from pathlib import Path
from typing import List

from dotenv import load_dotenv
from fastapi import APIRouter, FastAPI, HTTPException, Query
from motor.motor_asyncio import AsyncIOMotorClient
from pydantic import BaseModel, Field
from pymongo import ASCENDING, DESCENDING, IndexModel
from starlette.middleware.cors import CORSMiddleware

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / ".env")

mongo_url = os.environ.get("MONGO_URL", "mongodb://localhost:27017")
db_name = os.environ.get("DB_NAME", "la_peste_cu_fanel")
client = AsyncIOMotorClient(mongo_url)
db = client[db_name]

INDEXES: dict[str, list[IndexModel]] = {
    "status_checks": [
        IndexModel([("id", ASCENDING)], name="id", unique=True),
        IndexModel([("timestamp", DESCENDING)], name="timestamp_desc"),
    ],
    "scores": [
        IndexModel([("key", ASCENDING)], name="key", unique=True),
        IndexModel([("score", DESCENDING), ("updated_at", ASCENDING)], name="score_desc"),
    ],
}

async def ensure_indexes() -> None:
    for collection, models in INDEXES.items():
        for model in models:
            try:
                await db[collection].create_indexes([model])
            except Exception as exc:
                logging.getLogger(__name__).error(
                    "ensure_indexes(%s.%s): %s", collection, model.document["name"], exc
                )

app = FastAPI(title="La peste cu Fanel API", version="1.0.0")

@app.get("/health", include_in_schema=False)
@app.head("/health", include_in_schema=False)
async def health():
    return {"status": "ok"}

api_router = APIRouter(prefix="/api")

class StatusCheck(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    client_name: str
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class StatusCheckCreate(BaseModel):
    client_name: str

@api_router.get("/")
async def root():
    return {"message": "Hello World"}

@api_router.post("/status", response_model=StatusCheck)
async def create_status_check(input: StatusCheckCreate):
    status_obj = StatusCheck(**input.model_dump())
    await db.status_checks.insert_one(status_obj.model_dump())
    return status_obj

@api_router.get("/status", response_model=List[StatusCheck])
async def get_status_checks(limit: int = Query(20, ge=1, le=100)):
    docs = await db.status_checks.find({}, {"_id": 0}).sort("timestamp", -1).limit(limit).to_list(limit)
    return [StatusCheck(**doc) for doc in docs]

class ScoreIn(BaseModel):
    name: str = Field(min_length=1, max_length=20)
    score: int = Field(ge=0, le=1_000_000)

class ScoreEntry(BaseModel):
    name: str
    score: int
    updated_at: str

class ScoreResult(ScoreEntry):
    rank: int

@api_router.post("/scores", response_model=ScoreResult)
async def submit_score(body: ScoreIn):
    name = body.name.strip()
    if not name:
        raise HTTPException(status_code=422, detail="Name is required")
    key = name.lower()
    now = datetime.now(timezone.utc).isoformat()
    # A single atomic upsert preserves the highest score even for simultaneous submits.
    await db.scores.update_one(
        {"key": key},
        {
            "$max": {"score": body.score},
            "$set": {"name": name, "updated_at": now},
            "$setOnInsert": {"key": key},
        },
        upsert=True,
    )
    doc = await db.scores.find_one({"key": key}, {"_id": 0})
    rank = await db.scores.count_documents({"score": {"$gt": doc["score"]}}) + 1
    return ScoreResult(name=doc["name"], score=doc["score"], updated_at=doc["updated_at"], rank=rank)

@api_router.get("/leaderboard", response_model=List[ScoreEntry])
async def get_leaderboard(limit: int = Query(50, ge=1, le=100)):
    docs = await db.scores.find({}, {"_id": 0, "key": 0}).sort([("score", -1), ("updated_at", 1)]).limit(limit).to_list(limit)
    return [ScoreEntry(**doc) for doc in docs]

app.include_router(api_router)
app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

@app.on_event("startup")
async def start_index_build():
    app.state.index_task = asyncio.create_task(ensure_indexes())

@app.on_event("shutdown")
async def shutdown_db_client():
    task = getattr(app.state, "index_task", None)
    if task:
        task.cancel()
        with suppress(asyncio.CancelledError):
            await task
    client.close()
