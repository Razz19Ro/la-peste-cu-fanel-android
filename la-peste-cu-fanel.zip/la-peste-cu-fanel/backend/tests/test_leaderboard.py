import os
import uuid
from pathlib import Path
import pytest
import requests
from pymongo import MongoClient
from dotenv import load_dotenv

PROJECT_ROOT = Path(__file__).resolve().parents[2]
load_dotenv(PROJECT_ROOT / "frontend" / ".env")
load_dotenv(PROJECT_ROOT / "backend" / ".env")
BASE_URL = os.environ.get("EXPO_PUBLIC_BACKEND_URL", "http://localhost:8001").rstrip("/")
CREATED_KEYS = []

@pytest.fixture(scope="module")
def api():
    s = requests.Session()
    s.headers.update({"Content-Type": "application/json"})
    yield s
    if os.environ.get("MONGO_URL") and os.environ.get("DB_NAME"):
        db = MongoClient(os.environ["MONGO_URL"])[os.environ["DB_NAME"]]
        for k in CREATED_KEYS:
            db.scores.delete_one({"key": k})

def uniq():
    n = f"TEST_{uuid.uuid4().hex[:8]}"
    CREATED_KEYS.append(n.lower())
    return n

def test_api_root(api):
    assert api.get(f"{BASE_URL}/api/").status_code == 200

def test_submit_score_returns_rank(api):
    n = uniq()
    r = api.post(f"{BASE_URL}/api/scores", json={"name": n, "score": 123})
    assert r.status_code == 200, r.text
    d = r.json()
    assert d["name"] == n and d["score"] == 123
    assert isinstance(d["rank"], int) and d["rank"] >= 1
    assert "updated_at" in d and "_id" not in d

def test_upsert_keeps_max_case_insensitive(api):
    n = uniq()
    api.post(f"{BASE_URL}/api/scores", json={"name": n, "score": 200})
    r_low = api.post(f"{BASE_URL}/api/scores", json={"name": n.upper(), "score": 50})
    assert r_low.status_code == 200 and r_low.json()["score"] == 200
    r_hi = api.post(f"{BASE_URL}/api/scores", json={"name": n.lower(), "score": 350})
    assert r_hi.json()["score"] == 350
    lb = api.get(f"{BASE_URL}/api/leaderboard?limit=100").json()
    matches = [e for e in lb if e["name"].lower() == n.lower()]
    assert len(matches) == 1 and matches[0]["score"] == 350

def test_rank_ordering(api):
    a, b = uniq(), uniq()
    ra = api.post(f"{BASE_URL}/api/scores", json={"name": a, "score": 999000}).json()
    rb = api.post(f"{BASE_URL}/api/scores", json={"name": b, "score": 999001}).json()
    ra = api.post(f"{BASE_URL}/api/scores", json={"name": a, "score": 0}).json()
    assert ra["score"] == 999000
    assert rb["rank"] < ra["rank"] and ra["rank"] == rb["rank"] + 1

def test_leaderboard_sorted(api):
    r = api.get(f"{BASE_URL}/api/leaderboard")
    assert r.status_code == 200
    data = r.json()
    assert isinstance(data, list)
    assert [e["score"] for e in data] == sorted([e["score"] for e in data], reverse=True)
    for e in data:
        assert "_id" not in e and "key" not in e

def test_name_trimmed(api):
    n = uniq()
    r = api.post(f"{BASE_URL}/api/scores", json={"name": f"  {n}  ", "score": 5})
    assert r.status_code == 200 and r.json()["name"] == n

@pytest.mark.parametrize("payload", [
    {"name": "", "score": 10}, {"name": "   ", "score": 10},
    {"name": "TEST_neg", "score": -1}, {"name": "TEST_" + "x" * 30, "score": 10},
    {"score": 10}, {"name": "TEST_noscore"},
])
def test_validation_422(api, payload):
    r = api.post(f"{BASE_URL}/api/scores", json=payload)
    assert r.status_code == 422, f"{payload} -> {r.status_code}"

def test_leaderboard_limit_validation(api):
    assert api.get(f"{BASE_URL}/api/leaderboard?limit=0").status_code == 422
    assert api.get(f"{BASE_URL}/api/leaderboard?limit=101").status_code == 422
    r = api.get(f"{BASE_URL}/api/leaderboard?limit=1")
    assert r.status_code == 200 and len(r.json()) <= 1
