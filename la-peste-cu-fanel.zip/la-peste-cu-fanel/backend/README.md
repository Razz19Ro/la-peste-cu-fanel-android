# Backend

FastAPI + Motor service for health checks, status checks and the online leaderboard.

Run from this directory after configuring `.env` and starting MongoDB:

```bash
pip install -r requirements.txt
uvicorn server:app --host 0.0.0.0 --port 8001 --reload
```

API:
- `GET /api/`
- `POST /api/scores` with `{ "name": "Fanel", "score": 120 }`
- `GET /api/leaderboard?limit=50`

The score collection uses a unique lowercase `key`; score updates use MongoDB `$max` so a lower submitted score cannot replace a player's best.
